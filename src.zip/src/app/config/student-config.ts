export const SETTINGS = {
    api: {
        apiEndpoint: '../assets/student-rank.json'
    }
}