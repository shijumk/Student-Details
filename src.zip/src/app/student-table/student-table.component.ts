import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { StudentDataService } from '../student-data.service';

@Component({
  selector: 'app-student-table',
  templateUrl: './student-table.component.html',
  styleUrls: ['./student-table.component.scss']
})
export class StudentTableComponent implements OnInit {

  constructor(private studentSvc: StudentDataService, private elemRef: ElementRef) { }

  studentTblHeadings: any;
  studentData: any;
  isShowLoader = true;
  errorMsg: string;
  isShowError = false;
  gridOptions: any;
  ngOnInit(): void {

  this.studentTblHeadings = [
    { field: 'student_id' },
    { field: 'name' },
    { field: 'dob'},
    { field: 'subject', filter: true },
    { field: 'rank', sortable: true },
    { field: 'result'}
  ];

  this.studentSvc.getStudentData().subscribe(response => {
      this.studentData = [];

      response.forEach(element => {
        element.subject_details.map(item => {
          this.studentData.push({
            student_id: element.student_id,
            name: element.name,
            dob: element.dob,
            subject : item.subject,
            rank : item.rank,
            result : item.result
          })
        });
      })
    }, error => {
        console.log(error);
    });
  }
}
